create a login page have useraname and password and submit button using xml language and java language. 
use a xml for frontend and java for backend
